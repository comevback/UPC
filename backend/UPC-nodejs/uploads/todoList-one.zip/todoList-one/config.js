export const mongoUrl = "mongodb+srv://xuxiang5012:986532xx@cluster0.xvxt0us.mongodb.net/todoList?retryWrites=true&w=majority";
